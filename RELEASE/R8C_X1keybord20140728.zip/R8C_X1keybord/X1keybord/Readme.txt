-------- PROJECT GENERATOR --------
PROJECT NAME :	X1keybord
PROJECT DIRECTORY :	C:\Users\uts\SkyDrive\Documents\HEW\R8C_X1keybord\X1keybord
CPU SERIES :	R8C/Tiny
CPU GROUP :	M12A
TOOLCHAIN NAME :	Renesas M16C Standard Toolchain
TOOLCHAIN VERSION :	6.00.00
GENERATION FILES :
    C:\Users\uts\SkyDrive\Documents\HEW\R8C_X1keybord\X1keybord\X1keybord.c
        main program file.
    C:\Users\uts\SkyDrive\Documents\HEW\R8C_X1keybord\X1keybord\nc_define.inc
        interrupt program.
START UP FILES :
    C:\Users\uts\SkyDrive\Documents\HEW\R8C_X1keybord\X1keybord\ncrt0.a30
    C:\Users\uts\SkyDrive\Documents\HEW\R8C_X1keybord\X1keybord\sfr_r8m12a.h
    C:\Users\uts\SkyDrive\Documents\HEW\R8C_X1keybord\X1keybord\sfr_r8m12a.inc
    C:\Users\uts\SkyDrive\Documents\HEW\R8C_X1keybord\X1keybord\sect30.inc

DATE & TIME : 2014/07/16 3:13:49
